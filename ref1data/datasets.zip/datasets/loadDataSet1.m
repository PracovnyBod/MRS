clear all;


load('dataset1.mat')




figure(1)


subplot(4,1,1)

plot(ds1_ventilator(:,1), ds1_ventilator(:,2))

subplot(4,1,2)

plot(ds1_spirala(:,1), ds1_spirala(:,2))

subplot(4,1,3)

plot(ds1_snimac_1(:,1), ds1_snimac_1(:,2))

subplot(4,1,4)

plot(ds1_snimac_2(:,1), ds1_snimac_2(:,2))

